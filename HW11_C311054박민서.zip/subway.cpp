#include "subway.h"
#include <stack>

MatrixWGraph::MatrixWGraph(int n = 0) :node(n), count(0) {
	length = new int* [n];
	for (int i = 0; i < n; i++) {
		length[i] = new int[n];
		for (int j = 0; j < n; j++) {
			length[i][j] = MAXLEN;
		}
		length[i][i] = 0;
	}
	s = new bool[n]();
	dist = new pair<int,int>[n];
	stlist = new Station[n];
}

void MatrixWGraph::AddVertex(int num1, string name1, int num2, string name2) {

	Station station1(num1, name1);
	Station station2(num2, name2);

	int p1 = -1; //station1�� �ε�����
	int p2 = -1; //station2�� �ε�����
	for (int i = 0; i < count; i++) {
		if (stlist[i].num == station1.num && stlist[i].name == station1.name) {
			p1 = i;
		}
		if (stlist[i].num == station2.num && stlist[i].name == station2.name) {
			p2 = i;
		}
	}
	if (p1 < 0) {
		p1 = count;
		stlist[count++] = station1;
	}
	if (p2 < 0) {
		p2 = count;
		stlist[count++] = station2;
	}

	if (station1.name == station2.name) { //ȯ�¿�
		for (int i = 0; i < transfer.size(); i++) {
			if (stlist[transfer[i][0]].name == station1.name) {
				bool b1 = false, b2 = false;
				for (int j = 0; j < transfer[i].size(); j++) {
					if (p1 != transfer[i][j]) {
						length[p1][transfer[i][j]] = length[transfer[i][j]][p1] = 30;
					}
					else b1 = true;
					if (p2 != transfer[i][j]) {
						length[p2][transfer[i][j]] = length[transfer[i][j]][p2] = 30;
					}
					else b2 = true;
				}
				if (!b1) transfer[i].push_back(p1);
				if (!b2) transfer[i].push_back(p2);
				return;
			}
		}
		transfer.push_back({ p1,p2 });
		length[p1][p2] = length[p2][p1] = 30;
	}
	else {
		length[p1][p2] = length[p2][p1] = 60;
	}
	
}

void MatrixWGraph::Dijkstra(int line1, string src, int line2, string dst) {

	int srcnum, dstnum;
	for (int i = 0; i < node; i++) {
		if (stlist[i].num == line1 && stlist[i].name == src) {
			srcnum = i;
		}
		if (stlist[i].num == line2 && stlist[i].name == dst) {
			dstnum = i;
		}
	}

	for (int i = 0; i < node; i++) {
		dist[i] = make_pair(srcnum, length[srcnum][i]);
	}

	s[srcnum] = true;

	for (int i = 0; i < node - 2; i++) { //�������� ���� ���������� ���� ���� ���� n-2�� Ž��
		
		int temp = dstnum;
		for (int j = 0; j < node; j++) { //�������� �湮�� ��� ����
			if (!s[j] && dist[j].second < dist[temp].second) {
				temp = j;
			}
		}

		s[temp] = true;
		for (int j = 0; j < node; j++) {
			if (!s[j] && dist[temp].second + length[temp][j] < dist[j].second) {
				dist[j].second = dist[temp].second + length[temp][j];
				dist[j].first = temp;
			}
		}
	}

	PrintRoute(srcnum, dstnum);
}

void MatrixWGraph::PrintRoute(int srcnum, int dstnum) {
	stack<int> iroute;
	iroute.push(dstnum);

	int midnode = dstnum;
	int midtime = MAXLEN;
	while (iroute.top() != srcnum) {
		iroute.push(dist[iroute.top()].first);

		int temp = dist[iroute.top()].second - dist[dstnum].second / 2;
		if (abs(temp) < midtime) {
			midtime = abs(temp);
			midnode = iroute.top();
		}
	}
	int prenode = dstnum;
	 do{
		while (stlist[iroute.top()].name == stlist[prenode].name) {
			iroute.pop();
		}
		cout << stlist[iroute.top()].name << endl;
		prenode = iroute.top();
		iroute.pop();
	 } while (stlist[dstnum].name != stlist[prenode].name);
	PrintTime(dist[dstnum].second);
	cout << stlist[midnode].name << endl;

	PrintTime(dist[dstnum].second / 2 + midtime);
	PrintTime(dist[dstnum].second / 2 - midtime);

}

void MatrixWGraph::PrintTime(int time) {
	cout << time / 60 << ':' << (time % 60) / 10 << 0 << endl;
}